import os

BASE_DIR = os.path.dirname(__file__)

FLANGER_URLS = [
    'api.v1.urls.V1Urls',
]
