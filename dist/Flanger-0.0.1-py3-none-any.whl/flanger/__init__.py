"""
作者         xupeng
邮箱         874582705@qq.com
github主页   https://github.com/xupeng1206

"""

import os

__swagger__ = os.path.join(os.path.dirname(__file__), 'swagger')
__example__ = os.path.join(os.path.dirname(__file__), 'example')